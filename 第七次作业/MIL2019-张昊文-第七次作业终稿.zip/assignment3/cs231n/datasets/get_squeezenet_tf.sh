wget "http://cs231n.stanford.edu/squeezenet_tf2.zip"
unzip squeezenet_tf2.zip
rm squeezenet_tf2.zip
